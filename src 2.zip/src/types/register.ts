// src/types/register.ts
import './express';
